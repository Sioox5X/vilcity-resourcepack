Place VilCity Mannequin skin PNG files in this directory.
See ../../../../../NPC-SKINS.md for configuration and credit fields.
